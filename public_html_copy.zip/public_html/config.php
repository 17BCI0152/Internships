<?php
    $conn = mysqli_connect('localhost', 'id13984455_chiru', 'oCbo[YSYa7%$L-6}', 'id13984455_selex');
    if($conn->connect_error){
        echo "error in mysql";
    }
?>