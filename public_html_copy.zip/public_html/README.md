# Offline monitoring of Localizer(LLZ) system status

 This application is used to provide the status of Localizer to remote user in offline mode. It helps the remote user to understand and analyze the critical parameters.

# default admin password details

username - admin
password - mahesh
email - admin@gmail.com
user_type - admin

# default user password details
username - user 
password - user
email - user@gmail.com
user_type - user
