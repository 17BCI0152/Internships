<html>
    <head>
        <title>PMDT</title>
        <link rel="stylesheet" href="style.css">
        <link rel="stylesheet" href="bootstrap.css">
        
    </head>
    <body>
        <?php include "nav.php"; ?>
        
        <div class="col-sm-12 row" style="margin-top:3%;">
            <div class="col-sm-3">  <?php include "sidebar.php"; ?>
            </div>
            <div class="col-sm-4">
            <table> <a href="system.php" ><img src="images/airport_logo2.png" alt="Smiley face" height="100%" width="200%"></a>
            </table>
            </div>
        </div>
    </body>
</html>