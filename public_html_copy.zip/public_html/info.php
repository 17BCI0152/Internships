<html>

<head>
    <title>PMDT</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <style>
        
        
    </style>
    </head>
    <body>
    <?php include "nav.php"; ?>
        <div class="col-sm-12 row" style="margin-top:3%;">
            <div class="col-sm-9" style="margin-left: 17%;">
                <div class="card">
                    <div class="card-body">
                        <div class="inner" style="margin-left: 3%;">
                        <div>
                            <p style="text-align:center;color:blue;"> 
                                <h>Offline monitoring of Localizer(LLZ) system status</h></p> <br> <br>
                            <p>
                            
                                This application is used to provide the status of Localizer to remote user in offline mode. It helps the remote user to understand and analyze the critical parameters.
                            </p>
                            
                            <p style="color:blue;">
                                <br> <br>
                                Website Designed & Developed by VIT Students
                                <br><br>
                            </p>
                            <ol type="1">
                                <li>
                                <a href="https://github.com/CHIRU3223/Internships" target="_blank">
                                <div >
                                    <div>
                                        M.Chiranjeevi
                                    </div>
                                </div>
                                </a>
                                </li>

                                <li>
                                    <a href="https://github.com/mani44/PMDT" target="_blank">
                                    <div>
                                        <div >
                                            Manishankar K
                                        </div>
                                    </div>
                                    </a>
                                    
                                </li>
                                <li>
                                    <a href="#">
                                    <div >
                                        <div>
                                            Sahith D
                                        </div>
                                    </div>
                                    </a>
                                    
                                </li>
                                <li>
                                    
                                    <a href="#">
                                    <div>
                                        <div>
                                            Sujeeth ES
                                        </div>
                                    </div>
                                    </a>
                                </li>
                                
                            </ol>
                        <div>
                            <p style="color:blue;">
                
                                Guided & Monitored By<br> <br>
                                <ol style="font-weight:bold;">
                                    <li>Dr Chilaka Mahesh</li>
                                    <li>N Prasad</li>
                                </ol>   
                            </p>
                        </div>
        </div>
    </body>
</html>