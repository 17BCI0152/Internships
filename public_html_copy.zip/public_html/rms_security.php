<html>

<head>
    <title>PMDT</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    
</head>

<body>
    <?php include "nav.php"; ?>
        
        <div class="col-sm-12 row" style="margin-top:3%;">
            <div class="col-sm-3">
                <?php include "sidebar.php"; ?>
            </div>
            <div class="col-sm-9">
                <div class="card">
                    <div class="card-body">
                        <div class="inner" style="margin-left: 3%;">
                        <a href="rms_general.php"><button id="b1" style="background-color: blue;color: aliceblue;width: 90px;height: 30px;font-weight: bold;">General</button></a>
                        <a href="rms_station.php"><button id="b2" style="background-color: blue;color: aliceblue;width: 85px;height: 30px;font-weight: bold;">Station</button></a>
                        <a href="rms_config_ad.php"><button id="b3" style="background-color: blue;color: aliceblue;width: 100px;height: 30px;font-weight: bold;">A/D data</button></a>
                        <a href="rms_security.php"><button id="b4" style="background-color: blue;color: aliceblue;width: 100px;height: 30px;font-weight: bold;">Security</button></a>
                        <div id="d4">
                                <table>
                                    <tr>
                                        <td>
                                            <table style="text_align:center;">
                                                <tr>
                                                    <td style="width:150px;text-align:center;height:25px;">User ID</td>
                                                    <td style="width:150px;text-align:center;">Password</td>
                                                    <td style="width:150px;text-align:center;">Level</td>
                                                </tr>
                                                <tr>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                    
                                                         
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td id=""style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                       
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                </tr>

                                            </table>
                                        </td>
                                        <td>
                                            <table>
                                                <tr>
                                                    <td style="width:150px;text-align:center;">User ID</td>
                                                    <td style="width:150px;text-align:center;">Password</td>
                                                    <td style="width:150px;text-align:center;">Level</td>
                                                </tr>
                                                <tr>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                       
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                       
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                    <td id="" style="width:150px;text-align:center;height:25px;">
                                                        
                                                    </td>
                                                </tr>
                                            </table>
                                        </td>
                                    </tr>
                                </table>
                            </div>

                        </div>

</div>
</div>
</div>
</div>
</body>

</html>